package com.sportradar.sdk.test.system.framework.livescout;

import com.sportradar.sdk.test.system.framework.common.Match;

public class LiveScoutMatch extends Match {

    public LiveScoutMatch() {
        this.subscribed = false;
        this.booked = true;
    }
}
