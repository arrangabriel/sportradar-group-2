/**
 * Contains Live Scout related entities
 */
package com.sportradar.sdk.feed.livescout.entities;