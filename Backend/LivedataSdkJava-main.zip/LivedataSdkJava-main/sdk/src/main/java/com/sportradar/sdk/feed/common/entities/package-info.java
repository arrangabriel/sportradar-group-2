/**
 * Contains common entities
 */
package com.sportradar.sdk.feed.common.entities;