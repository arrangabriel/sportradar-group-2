/**
 * Contains enums that are the same for multiple feeds
 */
package com.sportradar.sdk.feed.common.enums;