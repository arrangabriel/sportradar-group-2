/**
 * Contains common enums
 */
package com.sportradar.sdk.common.enums;