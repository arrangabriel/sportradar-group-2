/**
 * Contains SDK entry point
 */
package com.sportradar.sdk.feed.sdk;