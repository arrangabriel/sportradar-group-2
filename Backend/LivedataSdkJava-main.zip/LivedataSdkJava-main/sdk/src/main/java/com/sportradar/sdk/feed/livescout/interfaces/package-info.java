/**
 * Contains Live Scout related interfaces
 */
package com.sportradar.sdk.feed.livescout.interfaces;