/**
 * Contains classes and interfaces which are shared between different protocols.
 */
package com.sportradar.sdk.proto;