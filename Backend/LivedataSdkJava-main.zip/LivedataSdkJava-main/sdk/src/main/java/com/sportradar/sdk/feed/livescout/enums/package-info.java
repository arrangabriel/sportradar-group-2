/**
 * Contains Live Scout related enums
 */
package com.sportradar.sdk.feed.livescout.enums;