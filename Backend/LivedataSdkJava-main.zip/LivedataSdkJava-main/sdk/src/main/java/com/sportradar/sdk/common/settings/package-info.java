/**
 * Contains classes and interfaces associated with settings
 */
package com.sportradar.sdk.common.settings;