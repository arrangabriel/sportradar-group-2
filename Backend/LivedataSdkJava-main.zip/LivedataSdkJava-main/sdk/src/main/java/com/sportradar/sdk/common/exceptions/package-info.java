/**
 * Contains common exceptions
 */
package com.sportradar.sdk.common.exceptions;