/**
 * RateGate used for rate-limiting.
 */
package com.sportradar.sdk.common.rategate;