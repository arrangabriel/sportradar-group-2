/**
 * Contains interfaces that are the same for multiple feeds
 */
package com.sportradar.sdk.feed.common.interfaces;